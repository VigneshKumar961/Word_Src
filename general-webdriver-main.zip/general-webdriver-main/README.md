# general-webdriver
A collection of Selenium WebDriver tests.

Watch the following YouTube playlist to learn about how this framework was built.

https://youtube.com/playlist?list=PLjfhFHeUQDOj9T1cRFf5z7SqxcDPeAAjA
