package io.automatenow.tests;

/**
 * @author Marco A. Cruz
 */
public class Weekdays {
    public static void main(String[] args) {
        String[] weekdays = {"Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday", "Sunday"};

        for (String weekday : weekdays) {
            System.out.println(weekday);
        }
    }
}
